﻿namespace StudentManagement.Modal
{
    public class Student
    {
        public String name ="";
        public int rollNumber = 0;
        public int age = 0;
        public int st_class = 0;
        public float eng = 0;
        public float maths = 0;
        public float sc = 0;
        public double total = 0;
        public float avg = 0;
        public String grade = "";
    }
}
